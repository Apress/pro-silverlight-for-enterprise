﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using System.Windows.Threading;

namespace myAlbum
{
    public partial class Page : UserControl
    {
        //Different Uri for each Categories of Pictures
        List<Uri> natureUri;
        List<Uri> cartoonUri;
        List<Uri> beachUri;

        //Different Uri for each Categories of Videos
        List<Uri> vcartoonUri;
        List<Uri> vpetsUri;
        List<Uri> vsportsUri;

        //Different Uri for each Categories of videos thumbnails
        List<Uri> vthumbcartoonUri;
        List<Uri> vthumbpetsUri;
        List<Uri> vthumbsportsUri;

        //timer for automatic slideshow
        DispatcherTimer timer = new DispatcherTimer();

        //Uri list for storing reference for active picture category
        List<Uri> currentPicCategory;
        //Uri list for storing reference for active video category
        List<Uri> currentVidCategory;
        List<Uri> currentVidThumbCategory;
        
        //int variable to iterate through uri collection
        int playIndex;
        
        //string to determine current show mode i.e. Video or Picture
        string showMode;
        public Page()
        {
            InitializeComponent();

            currentPicCategory = new List<Uri>();
            currentVidCategory = new List<Uri>();
            currentVidThumbCategory = new List<Uri>();
            playIndex = 0;

            //Default mode is Picture
            showMode = "picture";

            //Different picture categories intialization
            //Any number of images can be added to album by providing uri in below listed category. New category can also be added.
            //Nature pictures
            natureUri = new List<Uri>();
            natureUri.Add(new Uri("nature/01.jpg", UriKind.Relative));
            natureUri.Add(new Uri("nature/02.jpg", UriKind.Relative));
    
            //Beach Pictures
            beachUri = new List<Uri>();
            beachUri.Add(new Uri("beach/01.jpg", UriKind.Relative));
            beachUri.Add(new Uri("beach/02.jpg", UriKind.Relative));


            //cartoon pictures
            cartoonUri = new List<Uri>();
            cartoonUri.Add(new Uri("cartoon/01.jpg", UriKind.Relative));
            cartoonUri.Add(new Uri("cartoon/02.jpg", UriKind.Relative));
  

            //Different video categories intialization
            //Any number of videos can be added to album by providing uri in below listed category. New category can also be added.
            //Cartoon videos
            vcartoonUri = new List<Uri>();
            vcartoonUri.Add(new Uri("/vcartoon/01.wmv", UriKind.Relative));

            //cartoon thumbnails
            vthumbcartoonUri = new List<Uri>();
            vthumbcartoonUri.Add(new Uri("vcartoon/01.jpg", UriKind.Relative));

            //pets videos
            vpetsUri = new List<Uri>();
            vpetsUri.Add(new Uri("/vpets/01.wmv", UriKind.Relative));
            //pets thumbnails
            vthumbpetsUri = new List<Uri>();
            vthumbpetsUri.Add(new Uri("vpets/01.jpg", UriKind.Relative));

            //sports videos
            vsportsUri = new List<Uri>();
            vsportsUri.Add(new Uri("/vsports/01.wmv", UriKind.Relative));
            //sports thumbnails
            vthumbsportsUri = new List<Uri>();
            vthumbsportsUri.Add(new Uri("vsports/01.jpg", UriKind.Relative));


            //Default picture category
            currentPicCategory = natureUri;
            //Set startup picture and thumbnails
            showPicture();

        }



        //Previous button
        private void prev_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (showMode == "picture")
            {
                if (playIndex == 0)
                    playIndex = currentPicCategory.Count - 1;
                else
                    playIndex--;

                showPicture();
            }
            else
            {
                if (playIndex == 0)
                    playIndex = currentVidCategory.Count - 1;
                else
                    playIndex--;

                playVideo();

            }
        }
        //Next button
        private void next_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (showMode == "picture")
            {
                if (playIndex == currentPicCategory.Count - 1)
                    playIndex = 0;
                else
                    playIndex++;

                showPicture();
            }
            else 
            {
                if (playIndex == currentVidCategory.Count - 1)
                    playIndex = 0;
                else
                    playIndex++;

                playVideo();

            }

        }


        //categories MouseOver & MouseLeave animations
        private void categories_MouseEnter(object sender, MouseEventArgs e)
        {
            grow.Stop();
            TextBlock txtRef = (TextBlock)sender;
            grow.SetValue(Storyboard.TargetNameProperty, txtRef.Name);
            grow.Begin();
        }

        private void categories_MouseLeave(object sender, MouseEventArgs e)
        {
            shrink.Stop();
            TextBlock txtRef = (TextBlock)sender;
            shrink.SetValue(Storyboard.TargetNameProperty, txtRef.Name);
            shrink.Begin();
        }


        //Picture Categories MouseLeftButtonDown
        private void picCategories_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TextBlock catRef = (TextBlock)sender;
            switch (catRef.Name.ToUpper())
            {
                case "CATNATURE":
                    currentPicCategory = natureUri;
                    currentView.Text = "Nature";
                    break;

                case "CATBEACH":
                    currentPicCategory = beachUri;
                    currentView.Text = "Beach";
                    break;

                case "CATCARTOON":
                    currentPicCategory = cartoonUri;
                    currentView.Text = "Cartoon";
                    break;
            }
            showMode = "picture";
            //changing visibility of round play button according to play mode
            Play.Visibility = Visibility.Visible;
            Stop.Visibility = Visibility.Collapsed;
            //changing visibility of imaStage & vidStage according to play mode
            vidStage.Visibility = Visibility.Collapsed;
            imgStage.Visibility = Visibility.Visible;
            showPicture();
            playIndex = 0;
        }

        //Video Categories MouseLeftButtonDown
        private void vidCategories_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            TextBlock catRef = (TextBlock)sender;
            switch (catRef.Name.ToUpper())
            {
                case "VCATSPORTS":
                    currentVidCategory = vsportsUri;
                    currentVidThumbCategory = vthumbsportsUri;
                    currentView.Text = "Sports";
                    break;

                case "VCATPETS":
                    currentVidCategory = vpetsUri;
                    currentVidThumbCategory = vthumbpetsUri;
                    currentView.Text = "Pets";
                    break;

                case "VCATCARTOON":
                    currentVidCategory = vcartoonUri;
                    currentVidThumbCategory = vthumbcartoonUri;
                    currentView.Text = "Cartoon";
                    break;
            }
            showMode = "video";
            //changing visibility of round play button according to play mode
            Play.Visibility = Visibility.Collapsed;
            Stop.Visibility = Visibility.Visible;
            //changing visibility of imaStage & vidStage according to play mode
            imgStage.Visibility = Visibility.Collapsed;
            vidStage.Visibility = Visibility.Visible;
            playIndex = 0;
            playVideo();
        }
        //toggle button for changing view between Full & Normal screen
        private void goFullscreen_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Application.Current.Host.Content.IsFullScreen = !Application.Current.Host.Content.IsFullScreen;
            if (goFullscreen.Text.ToUpper() == "FULL SCREEN")
                goFullscreen.Text = "Normal Screen";
            else
                goFullscreen.Text = "Full Screen";
        }
        //central method for showing picture of current gallery
        private void showPicture()
        {
            //shows the image
            imgStage.SetValue(Image.SourceProperty, new BitmapImage(currentPicCategory[playIndex]));

            //creates thumbnails of current category in preview pane
            createThumbnails();

            //synchronize  the thumbnail with active picture in imgStage image control
            fadeThumb.Stop();
            fadeThumb.SetValue(Storyboard.TargetNameProperty, "thumb" + playIndex);
            fadeThumb.Begin();
            fadeIn.Begin();
        }
        //central method for playing video of current gallery
        private void playVideo()
        {
            //playes the video
            vidStage.SetValue(MediaElement.SourceProperty, currentVidCategory[playIndex]);
            vidStage.AutoPlay = true;
            
            //creates thumbnails of current category in preview pane
            createThumbnails();

            //synchronize  the thumbnail with active video in vidStage media element 
            fadeThumb.Stop();
            fadeThumb.SetValue(Storyboard.TargetNameProperty, "thumb" + playIndex);
            fadeThumb.Begin();
            fadeIn.Begin();
        }

        //central method for creating thumbnails of current gallery
        private void createThumbnails()
        {
            //prevent duplication & messup of thumbnails by clearing previous thumbnails
            thumbBar.Children.Clear();
            int idx = 0;

            if (showMode.ToUpper() == "PICTURE")
            {
                foreach (Uri item in currentPicCategory)
                {
                    Image thumbnails = new Image();
                    //Right margin for each thumbnail 
                    thumbnails.Margin = new Thickness(0, 0, 10, 0);
                    //Unique naming for each thumbnail to reference them later in codeBehind
                    thumbnails.SetValue(NameProperty, "thumb" + idx);
                    //set thumbnail image control source property
                    thumbnails.Source = new BitmapImage(item);
                    //on mouseOver, cursor will be changed to Hand from Arrow
                    thumbnails.Cursor = Cursors.Hand;
                    //Opacity decresed
                    thumbnails.Opacity = 0.4;
                    //add thumbnails image controls to stackpanel thumbBar 
                    thumbBar.Children.Add(thumbnails);
                    //Dynamically attaching event handlers MouseLeftButtonDown & MouseEnter to each thumbnails
                    thumbnails.MouseLeftButtonDown += new MouseButtonEventHandler(thumbnails_MouseLeftButtonDown);
                    thumbnails.MouseEnter += new MouseEventHandler(thumbnails_MouseEnter);
                    //increment in index that will be used in naming of each thumbnails
                    idx++;
                }
            }
            
            else // the mode is video.
            
            {
                foreach (Uri item in currentVidThumbCategory)
                {
                    //in next chapter version we will use usercontrol instead of Image
                    Image vthumbnails = new Image();
                    //Right margin for each thumbnail 
                    vthumbnails.Margin = new Thickness(0, 0, 10, 0);
                    //Unique naming for each thumbnail to reference them later in codeBehind
                    vthumbnails.SetValue(NameProperty, "thumb" + idx);
                    //set thumbnail image control source property
                    vthumbnails.Source = new BitmapImage(item);
                    //on mouseOver, cursor will be changed to Hand from Arrow
                    vthumbnails.Cursor = Cursors.Hand;
                    //Opacity decreased
                    vthumbnails.Opacity = 0.4;
                    //add thumbnails image controls to stackpanel thumbBar 
                    thumbBar.Children.Add(vthumbnails);
                    //Dynamically attaching event handlers MouseLeftButtonDown & MouseEnter to each thumbnails
                    vthumbnails.MouseLeftButtonDown += new MouseButtonEventHandler(thumbnails_MouseLeftButtonDown);
                    vthumbnails.MouseEnter += new MouseEventHandler(thumbnails_MouseEnter);
                    //increment in index that will be used in naming of each thumbnails
                    idx++;
                }

            }

        }

        // This event is raised when user mouse over on thumbnail & this changes Opacity to 1 
        public void thumbnails_MouseEnter(object sender, MouseEventArgs e)
        {
            //stop animation
            fadeThumb.Stop();
            //cast reference from sender object to Image control
            Image imgRef = (Image)sender;
            //using name property of above cast image, dynamically setting TargetNameProperty of fadeThumb storyboard
            fadeThumb.SetValue(Storyboard.TargetNameProperty, imgRef.Name);
            //start animation
            fadeThumb.Begin();

        }
        // This event is raised when user clicks on thumbnail & that image/video displays in imgStage/vidStage control
        public void thumbnails_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //cast reference from sender object to Image control
            Image img = (Image)sender;
            //using source property of above cast image, dynamically create bitmapImage to display in imgStage image control
            BitmapImage bmi = (BitmapImage)img.Source;
            if (showMode == "picture")
                imgStage.Source = new BitmapImage(bmi.UriSource);
            else
                //getting video source from thumbnail by some string manipulation
                //Note the use of Forward slash, we need it as Build action for Video file is set to "Content"
                vidStage.Source = new Uri("/" + bmi.UriSource.ToString().Replace(".jpg",".wmv"),UriKind.Relative );
            fadeIn.Begin();

        }

        //In picture gallery presentation mode, this event is raised every 4 secs
        void timer_Tick(object sender, EventArgs e)
        {
            if (playIndex == currentPicCategory.Count - 1)
                playIndex = 0;
            else
                playIndex++;

            showPicture();


        }
 

        private void playStopToggle(object sender, MouseButtonEventArgs e)
        {
            //start slideshow of pictures and start video 

            if (Play.Visibility == Visibility.Visible)
            {
                Play.Visibility = Visibility.Collapsed;
                Stop.Visibility = Visibility.Visible;
                
                if (showMode == "picture")
                {
                    timer.Interval = new TimeSpan(0, 0, 4);
                    timer.Start();
                    timer.Tick += new EventHandler(timer_Tick);
                }
                else
                {
                    vidStage.Play();
                }
            }
            else 
            {
                //stop the current presentation or Video

                Play.Visibility = Visibility.Visible ;
                Stop.Visibility = Visibility.Collapsed ;
                
                if (showMode == "picture")
                {
                    timer.Stop();
                }
                else
                {
                    vidStage.Pause();
                }
            }




        }

       
    }
}