﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
//added
using System.Windows.Threading;

namespace TechnologyOpinion
{
    [TemplatePart(Name = mediaPlayer.FadeIn, Type = typeof(Storyboard))]
    [TemplatePart(Name = mediaPlayer.FadeOut, Type = typeof(Storyboard))]
    [TemplatePart(Name = mediaPlayer.ForwardImage, Type = typeof(Image))]
    [TemplatePart(Name = mediaPlayer.FullScreenImage, Type = typeof(Image))]
    [TemplatePart(Name = mediaPlayer.MediaElement, Type = typeof(MediaElement))]
    [TemplatePart(Name = mediaPlayer.MediaSlider,Type = typeof(Slider))]
    [TemplatePart(Name = mediaPlayer.PlayImage, Type = typeof(Image))]
    [TemplatePart(Name = mediaPlayer.RewindImage, Type = typeof(Image))]
    [TemplatePart(Name = mediaPlayer.StopImage,Type = typeof(Image))]
    [TemplatePart(Name = mediaPlayer.VolumeMinusImage, Type = typeof(Image))]
    [TemplatePart(Name = mediaPlayer.VolumePlusImage, Type = typeof(Image))]


    public class mediaPlayer:Control 
    {
        #region Private fields

        //String for the media element template item.
        private const string MediaElement = "mediaElement";
        //String for the media slider template item.
        private const string MediaSlider = "mediaSlider";
        //String for the media player navigation control template item.
        private const string PlayImage = "playImage";
        private const string StopImage = "stopImage";
        private const string ForwardImage = "forwardImage";
        private const string RewindImage = "rewindImage";
        private const string VolumePlusImage = "volumePlusImage";
        private const string VolumeMinusImage = "volumeMinusImage";
        private const string FullScreenImage = "fullScreenImage";
        private const string FadeIn = "fadeIn";
        private const string FadeOut = "fadeOut";
        private double volumeValue = 0.1;
        
        //Animations
        private Storyboard _fadeIn;
        private Storyboard _fadeOut;
        
        // The main media element for playing audio and video.
        private MediaElement _mediaElement;

        // The slider for showing video progress and drag feature.
        private mediaSlider _mediaSlider;

        //Images for media player navigation 
        private Image _play;
        private Image _stop;
        private Image _forward;
        private Image _rewind;
        private Image _volPlus;
        private Image _volMinus;
        private BitmapImage _pauseState;
        private BitmapImage _playState;

        //DispatcherTimer object to update slider as video progresses
        private DispatcherTimer timer = new DispatcherTimer();


        #endregion

        #region Public fields
        //Advantage of C# 3.0 automatic properties
        public Uri playImgUri 
        {
          set 
            {_playState = new BitmapImage(value);
             _play.SetValue(Image.SourceProperty, _playState);
            }
        }
        
        public Uri pauseImgUri
        {set
            {_pauseState = new BitmapImage(value);}
        }
        
        public Uri stopImgUri
        {set
            {BitmapImage source = new BitmapImage(value);
             _stop.SetValue(Image.SourceProperty, source);
            }
        }
        
        public Uri forwardImgUri
        {set
            {BitmapImage source = new BitmapImage(value);
             _forward.SetValue(Image.SourceProperty, source);
            }
        }

        public Uri rewindImgUri
        {set
            {BitmapImage source = new BitmapImage(value);
             _rewind.SetValue(Image.SourceProperty, source);
            }
        }

        public Uri volPlusImgUri
        {set
            {BitmapImage source = new BitmapImage(value);
             _volPlus.SetValue(Image.SourceProperty, source);
            }
        }
        
        public Uri volMinusImgUri
        {set
            {BitmapImage source = new BitmapImage(value);
             _volMinus.SetValue(Image.SourceProperty, source);
            }
        }

        public void stopMediaPlayer()
        {_mediaElement.Stop();
        }

        public void setMediaPlayerSource(Uri mediaFile)
        {_mediaElement.Source = mediaFile;
        }
        #endregion

        #region mediaPlayer constructor
        public mediaPlayer()
        {
            this.DefaultStyleKey = typeof(mediaPlayer);
            this.Loaded += new RoutedEventHandler(mediaPlayer_Loaded);
            OnApplyTemplate();
            timer.Interval = new TimeSpan(0, 0, 1);
        }
        #endregion
        
        #region TemplateHandlers
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            GetTemplateChildren();

            //Assign Event handlers
            timer.Tick += new EventHandler(timer_Tick);

            if (_mediaElement != null)
                _mediaElement.MediaOpened += new RoutedEventHandler(_mediaElement_MediaOpened);

            if (_mediaSlider != null)
                _mediaSlider.DragCompleted += new System.Windows.Controls.Primitives.DragCompletedEventHandler(_mediaSlider_DragCompleted);

            if (_play != null)
            {
                _play.MouseLeftButtonDown += playPause_MouseLeftButtonDown;
                _play.MouseEnter += Control_MouseEnter;
                _play.MouseLeave += Control_MouseLeave;
            }
            if (_stop != null)
            {
                _stop.MouseLeftButtonDown += Control_MouseLeftButtonDown;
                _stop.MouseEnter += Control_MouseEnter;
                _stop.MouseLeave += Control_MouseLeave;
            }
            if (_forward != null)
            {
                _forward.MouseLeftButtonDown += Control_MouseLeftButtonDown;
                _forward.MouseEnter += Control_MouseEnter;
                _forward.MouseLeave += Control_MouseLeave;
            }
            if (_rewind != null)
            {
                _rewind.MouseLeftButtonDown += Control_MouseLeftButtonDown;
                _rewind.MouseEnter += Control_MouseEnter;
                _rewind.MouseLeave += Control_MouseLeave;
            }
            if (_volMinus != null)
            {
                _volMinus.MouseLeftButtonDown += Control_MouseLeftButtonDown;
                _volMinus.MouseEnter += Control_MouseEnter;
                _volMinus.MouseLeave += Control_MouseLeave;
            }
            if (_volPlus != null)
            {
                _volPlus.MouseLeftButtonDown += Control_MouseLeftButtonDown;
                _volPlus.MouseEnter += Control_MouseEnter;
                _volPlus.MouseLeave += Control_MouseLeave;
            }

        }



       
        private void GetTemplateChildren()
        {
            _mediaElement = base.GetTemplateChild(MediaElement) as MediaElement;
            _mediaSlider = base.GetTemplateChild(MediaSlider) as mediaSlider;
            _play = base.GetTemplateChild(PlayImage) as Image;
            _stop = base.GetTemplateChild(StopImage) as Image;
            _forward = base.GetTemplateChild(ForwardImage) as Image;
            _rewind = base.GetTemplateChild(RewindImage) as Image;
            _volPlus = base.GetTemplateChild(VolumePlusImage) as Image;
            _volMinus = base.GetTemplateChild(VolumeMinusImage) as Image;
            _fadeIn = base.GetTemplateChild(FadeIn) as Storyboard;
            _fadeOut = base.GetTemplateChild(FadeOut) as Storyboard;
        }

        #endregion

        #region EventHandlers


        void Control_MouseEnter(object sender, MouseEventArgs e)
        {
            Image imgRef = new Image();
            imgRef = (Image)sender;
            _fadeIn.Stop();
            _fadeIn.SetValue(Storyboard.TargetNameProperty, imgRef.Name);
            _fadeIn.Begin();

        }

        void Control_MouseLeave(object sender, MouseEventArgs e)
        {
            Image imgRef = new Image();
            imgRef = (Image)sender;
            _fadeOut.Stop();
            _fadeOut.SetValue(Storyboard.TargetNameProperty, imgRef.Name);
            _fadeOut.Begin();

        }
        void mediaPlayer_Loaded(object sender, RoutedEventArgs e)
        {
            this.ApplyTemplate();
        }

        void playPause_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_mediaElement.CurrentState == MediaElementState.Playing)
            {
                _mediaElement.Pause();
                _play.SetValue(Image.SourceProperty, _playState);
                ToolTipService.SetToolTip(_play, "Play");
            }
            else
            {
                _mediaElement.Play();
                _play.SetValue(Image.SourceProperty, _pauseState);
                ToolTipService.SetToolTip(_play, "Pause");

            }
        }

        void Control_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Image imgRef = new Image();
            imgRef = (Image)sender;

            switch (imgRef.Name)
            {
                case StopImage :
                _mediaElement.Stop();
                _play.SetValue(Image.SourceProperty, _playState);
                break;

                case ForwardImage:
                _mediaElement.Position = _mediaElement.Position.Add(new TimeSpan(0, 0, 5));
                break;

                case RewindImage:
                _mediaElement.Position = _mediaElement.Position.Subtract(new TimeSpan(0, 0, 5));
                break;

                case VolumePlusImage:
                _mediaElement.Volume = _mediaElement.Volume + volumeValue;
                break;

                case VolumeMinusImage:
                _mediaElement.Volume = _mediaElement.Volume - volumeValue;
                break;

            }
        }

        void _mediaSlider_DragCompleted(object sender, System.Windows.Controls.Primitives.DragCompletedEventArgs e)
        {
            _mediaElement.Position = TimeSpan.FromSeconds(_mediaSlider.Value);
        }

        void _mediaElement_MediaOpened(object sender, RoutedEventArgs e)
        {
            _mediaSlider.Maximum = _mediaElement.NaturalDuration.TimeSpan.TotalSeconds;
            timer.Start();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            if (_mediaSlider.isDragging == false)
                _mediaSlider.Value = _mediaElement.Position.TotalSeconds;
        }
       #endregion
    }
}
