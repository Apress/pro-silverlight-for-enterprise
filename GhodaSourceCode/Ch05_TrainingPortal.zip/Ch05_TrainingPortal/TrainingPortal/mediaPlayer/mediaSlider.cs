﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Windows.Controls.Primitives;

namespace TechnologyOpinion
{
    [TemplatePart(Name = mediaSlider.HorizontalThumb, Type = typeof(Thumb))]

    public class mediaSlider : Slider
    {
        #region Private fields
        private const string HorizontalThumb = "HorizontalThumb";
        private Thumb _horizontalThumb;
        #endregion

        #region Public fields
        public bool isDragging
        {
            get { return _horizontalThumb.IsDragging; }
        }
        public event DragCompletedEventHandler DragCompleted;
        #endregion
        
        public mediaSlider()
        {
            this.DefaultStyleKey = typeof(mediaSlider);
            this.Loaded += new RoutedEventHandler(mediaSlider_Loaded);
            OnApplyTemplate();

        }

        #region TemplateHandlers
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            getTemplateChildren();
            if (_horizontalThumb != null)
            {
                _horizontalThumb.DragCompleted += new DragCompletedEventHandler(OnDragCompleted);

            }
        }
        #endregion

        #region EventHandlers
        void mediaSlider_Loaded(object sender, RoutedEventArgs e)
        {
            this.ApplyTemplate();
        }

        private void getTemplateChildren()
        {
            _horizontalThumb = GetTemplateChild(HorizontalThumb) as Thumb;
        }

        private void OnDragCompleted(object sender, DragCompletedEventArgs e)
        {
            DragCompleted(this, e);
        }
        #endregion

        

    }
}
