﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Windows.Media.Imaging;

namespace TechnologyOpinion
{
    [TemplatePart(Name = thumbnails.Title, Type = typeof(HyperlinkButton))]
    [TemplatePart(Name = thumbnails.LaunchVideo, Type = typeof(TextBlock))]
    [TemplatePart(Name = thumbnails.LaunchImage, Type = typeof(TextBlock))]

    public class thumbnails:Control
    {
        #region Private Fields
        
        private const string Title = "Title";
        private const string LaunchVideo = "launchVid";
        private const string LaunchImage = "launchImage";
        private const string LayoutRoot = "LayoutRoot";

        private HyperlinkButton _title;
        private TextBlock _launchVideo;
        private TextBlock _launchImage;
        private Grid _layoutRoot;
        private Storyboard fadeIn=new Storyboard();
        private Storyboard fadeOut = new Storyboard();
        private DoubleAnimation In=new DoubleAnimation();
        private DoubleAnimation Out = new DoubleAnimation();

        #endregion

        #region Public Fields

        public event MouseButtonEventHandler onLaunchImage;
        public event MouseButtonEventHandler onLaunchVideo;
        public event MouseEventHandler onThumbnailEnter;

        public string titleUri { get; set; }
        public string vidUri { get; set; }
        public string imageUri { get; set; }
        public string titleText { get; set; }
        public string abstractText { get; set; }
        
        #endregion

        public thumbnails()
        {     
        this.DefaultStyleKey=typeof(thumbnails);
        this.Loaded += thumbnails_Loaded;
        OnApplyTemplate();
        }

        #region TemplateHandlers
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            GetTemplateChildren();
            //assign
            if (_launchVideo != null)
            {
                if (vidUri == null || vidUri=="") 
                    _launchVideo.Visibility = Visibility.Collapsed;
                else
                    _launchVideo.MouseLeftButtonDown += launch_MouseLeftButtonDown;
            }

            if (_launchImage != null)
            {
                if (imageUri == null || imageUri=="")
                    _launchImage.Visibility = Visibility.Collapsed;
                else
                    _launchImage.MouseLeftButtonDown += launch_MouseLeftButtonDown;

            }
            if (_title != null)
                {
                   _title.DataContext = titleText;

                   if (titleUri != null )
                        _title.NavigateUri = new Uri(titleUri,UriKind.RelativeOrAbsolute); 
                }

            if (_layoutRoot != null)
            {
                _layoutRoot.MouseEnter += new MouseEventHandler(_layoutRoot_MouseEnter);
                _layoutRoot.MouseLeave += new MouseEventHandler(_layoutRoot_MouseLeave);
                ToolTipService.SetToolTip(_layoutRoot, "Click to visit...");
            }

        }


        private void GetTemplateChildren()
        {
            _title = base.GetTemplateChild(Title) as HyperlinkButton;
            _launchVideo = base.GetTemplateChild(LaunchVideo) as TextBlock;
            _launchImage = base.GetTemplateChild(LaunchImage) as TextBlock;
            _layoutRoot = base.GetTemplateChild(LayoutRoot) as Grid;
        }

        

        #endregion

        #region Event handler
        void thumbnails_Loaded(object sender, RoutedEventArgs e)
        {
            this.ApplyTemplate();
            //setting storyboard and animations
            //fadeIn
            In.From = 0.6;
            In.To = 1;
            In.SpeedRatio = 2;
            Storyboard.SetTarget(In, _layoutRoot);
            Storyboard.SetTargetProperty(In, new PropertyPath("(Grid.Opacity)"));
            fadeIn.Children.Add(In);
            //fadeOut
            Out.From = 1;
            Out.To =0.6;
            In.SpeedRatio = 3;
            Storyboard.SetTarget(Out, _layoutRoot);
            Storyboard.SetTargetProperty(Out, new PropertyPath("(Grid.Opacity)"));
            fadeOut.Children.Add(Out);
        }

        void launch_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TextBlock txtRef = new TextBlock();
            txtRef = (TextBlock)sender;

            switch (txtRef.Name)
            {
                case LaunchVideo:
                    onLaunchVideo(this,e);
                    break;

                case LaunchImage:
                    onLaunchImage(this,e);
                    break;
            }
                    
        }

        void _layoutRoot_MouseLeave(object sender, MouseEventArgs e)
        {
            fadeOut.Stop();
            fadeOut.Begin();
        }

        void _layoutRoot_MouseEnter(object sender, MouseEventArgs e)
        {
            fadeIn.Stop();
            fadeIn.Begin();
            onThumbnailEnter(this, e);
        }

        #endregion
    }
}
