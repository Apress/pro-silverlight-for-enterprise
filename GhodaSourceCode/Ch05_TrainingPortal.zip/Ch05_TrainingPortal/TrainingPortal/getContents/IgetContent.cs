﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace getContents
{
    // NOTE: If you change the interface name "IgetContent" here, you must also update the reference to "IgetContent" in Web.config.
    [ServiceContract]
    public interface IgetContent
    {
        [OperationContract]
        menuBinding[] menuClient(string connectionString);
        [OperationContract]
        appContents[] contentClient(string selectedItem, string selectedMenuId, string connectionString);
    }

    [DataContract]
    public class menuBinding
    {
        [DataMember]
        public int Id;
        [DataMember]
        public string Title;
        [DataMember]
        public List<string> Items;
    }
    [DataContract]
    public class appContents
    {
        [DataMember]
        public string Title;
        [DataMember]
        public string Abstract;
        [DataMember]
        public string ImageUri;
        [DataMember]
        public string VidUri;
        [DataMember]
        public string TitleUri;
    }
}
