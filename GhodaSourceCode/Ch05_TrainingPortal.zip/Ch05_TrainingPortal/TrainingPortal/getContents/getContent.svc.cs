﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace getContents
{
    // NOTE: If you change the class name "getContent" here, you must also update the reference to "getContent" in Web.config.
    public class getContent : IgetContent
    {
        private appContents[] content;
        private SQLDBDataContext db;


        public menuBinding[] menuClient(string connectionString)
        {
            db = new SQLDBDataContext(connectionString);

            menuBinding[] menuData =
                (from cat in db.Categories
                 select new menuBinding()
                 {
                     Id = (int)cat.Id,
                     Title = (string)cat.Title,
                     Items = (from row in db.tpContents
                              where row.Id == cat.Id
                              select (string)row.Track).Distinct().ToList()
                 }).ToArray();

            return menuData;
        }

        public appContents[] contentClient(string selectedItem, string selectedMenuId,string connectionString)
        {
            db = new SQLDBDataContext(connectionString);

            var rowData =
                 (from cat in db.Categories
                  where cat.Id == int.Parse(selectedMenuId)
                  select new
                  {
                      trainings = (from training in db.tpContents
                                   where training.Track == selectedItem
                                   select new appContents()
                                   {
                                       Title = training.Title,
                                       Abstract = training.Abstract,
                                       TitleUri = training.TitleUri,
                                       ImageUri = training.ImgUri,
                                       VidUri = training.VidUri,
                                   }
                    )

                  });

            foreach (var item in rowData)
            {
                content = item.trainings.ToArray<appContents>();
            }

            return content;
        }

    }
}
