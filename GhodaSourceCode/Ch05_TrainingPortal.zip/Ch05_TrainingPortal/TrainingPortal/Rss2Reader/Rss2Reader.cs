﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using System.Text.RegularExpressions;
using System.Windows.Browser;
using System.ServiceModel.Syndication;
using System.Windows.Data;
using System.Collections.ObjectModel;
using System.Linq;
using System.Xml;
using System.Windows.Controls.Primitives;

namespace TechnologyOpinion
{
    [TemplatePart(Name = Rss2Reader.FeedList, Type = typeof(ListBox))]
   
    public class Rss2Reader: Control
    {
        #region Private Fields
        private const string FeedList = "feedList";

        private ListBox _feedList;

        private WebClient wc = new WebClient();
        
        #endregion


        #region Public Fields

        public void getFeed( Uri feedAddress)
        {
            wc.OpenReadAsync(feedAddress);
        }

        #endregion


        public Rss2Reader()
        {
            this.DefaultStyleKey = typeof(Rss2Reader);
            OnApplyTemplate();
            this.Loaded += new RoutedEventHandler(Rss2Reader_Loaded);
            wc.OpenReadCompleted += new OpenReadCompletedEventHandler(wc_OpenReadCompleted);
        }

        
        #region TemplateHandlers

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            GetTemplateChildren();
        }

        private void GetTemplateChildren()
        {
            _feedList = base.GetTemplateChild(FeedList) as ListBox;
        }

        #endregion

        #region EventHandlers

        void Rss2Reader_Loaded(object sender, RoutedEventArgs e)
        {
            this.ApplyTemplate();
        }

        void wc_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                // Load feed into SyndicationFeed
                XmlReader reader = XmlReader.Create(e.Result);
                SyndicationFeed feed = SyndicationFeed.Load(reader);

                // Set up databinding
                _feedList.ItemsSource = (feed as SyndicationFeed).Items;
                
            }
        }

        #endregion

    }

    #region Helper Classes
    // Helper classes to shape up received data for binding
    public class htmlFormat : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // Remove all HTML tags and new lines character and all spaces
            string returnValue = Regex.Replace(value as string, "<.*?>", "");
            returnValue = Regex.Replace(returnValue, @"\n+\s+", "\n\n");

            // Decode HTML entities
            returnValue = HttpUtility.HtmlDecode(returnValue);

            return returnValue;
        }
        // we need to implement IValueConverter interface member ConvertBack
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class linkFormat : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // Get the first link that will point to the post
            return ((Collection<SyndicationLink>)value).FirstOrDefault().Uri;
        }
        // we need to implement IValueConverter interface member ConvertBack

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    #endregion
}
