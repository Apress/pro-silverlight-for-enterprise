﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using TechnologyOpinion;
using System.Collections.Generic;

namespace TechnologyOpinion
{
    [TemplatePart(Name = panelMenu.MenuDetail, Type = typeof(ListBox))]
    [TemplatePart(Name = panelMenu.MenuMaster, Type = typeof(StackPanel))]
    [TemplatePart(Name = panelMenu.CurrentSelection, Type = typeof(TextBlock))]

    public class panelMenu:Control
    {
        #region Private Fields
        private const string MenuMaster = "menuMaster";
        private const string MenuDetail = "menuDetail";
        private const string CurrentSelection= "currentSelection";
        //Maximum menu fields is 50
        private tpDataLayer.menuBinding[] menuData = new tpDataLayer.menuBinding[50] ;

        private StackPanel _menuMaster;
        private ListBox _menuDetail;
        private TextBlock _currentSelection;
        #endregion

        #region Public Fields
        public int selectedMenuId { get; set; }
        #endregion

        public panelMenu()
        {
            this.DefaultStyleKey = typeof(panelMenu);
            this.Loaded+=new RoutedEventHandler(panelMenu_Loaded);
            OnApplyTemplate();
        }



        #region Public Methods
        public event SelectionChangedEventHandler itemClicked;

        public void addMenuItem(int Id, string Title, List<string> Items)
        {
          
                menuData[Id] = new tpDataLayer.menuBinding();
                menuData[Id].Title = Title;
                menuData[Id].Items = Items;
                //add button
                Button menuButton = new Button();
                menuButton.FontSize = 12;
                menuButton.Height = 34;
                menuButton.Content = Title;
                menuButton.Name = Id.ToString();
                menuButton.Click+=new RoutedEventHandler(menuButton_Click);
                _menuMaster.Children.Add(menuButton);
        }

        #endregion

        #region Private Methods
       
        #endregion

        #region TemplateHandlers
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            GetTemplateChildren();
            //assign event handler only if not Null
            if (_menuDetail != null)
            {
                _menuDetail.SelectionChanged += new SelectionChangedEventHandler(_menuDetail_SelectionChanged);
            }
        }

        private void GetTemplateChildren()
        {
            _menuMaster= base.GetTemplateChild(MenuMaster) as StackPanel;
            _menuDetail = base.GetTemplateChild(MenuDetail) as ListBox;
            _currentSelection = base.GetTemplateChild(CurrentSelection) as TextBlock;
        }
        #endregion

        #region Event handler
        
        void panelMenu_Loaded(object sender, RoutedEventArgs e)
        {
            this.ApplyTemplate();
        }

        void menuButton_Click(object sender, RoutedEventArgs e)
        {
            Button btnRef = (Button)sender;
            selectedMenuId = int.Parse(btnRef.Name);
            _currentSelection.Text = btnRef.Content.ToString();
            _menuDetail.ItemsSource = menuData[selectedMenuId].Items;
        }
        void _menuDetail_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           itemClicked(this, e);
        }

        #endregion
    }
}
