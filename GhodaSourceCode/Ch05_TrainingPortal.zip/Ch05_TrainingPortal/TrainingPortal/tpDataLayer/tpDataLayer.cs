﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//Added
using System.Collections.Generic;
using System.Xml.Linq;
using System.Linq;
using System.Threading;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace TechnologyOpinion
{

    public class tpDataLayer
    {
        #region private fields
        //private fields
        private XDocument xDoc= new XDocument();
        private appContents[] content;
        private menuBinding[] menu;
        private feedItem[] feed;
        private string tpFeedURL;
        //Webclient object for various HTTP Request
        private WebClient menuClient = new WebClient();
        private WebClient contentClient = new WebClient();
        private WebClient configClient = new WebClient();
        private WebClient feedClient = new WebClient();
        private appConfig tpConfig = new appConfig();
        private ServiceGetContent.IgetContentClient service;
        #endregion

        #region public fields
        //Delegates
        public delegate void initPortalCompletedEventHandler(object sender, menuBinding[] eMenu, feedItem[] eFeed);
        public delegate void getContentCompletedEventHandler(object sender, appContents[] e);
        public event initPortalCompletedEventHandler initPortalCompleted;
        public event getContentCompletedEventHandler getContentCompleted;
        
        #endregion

        #region Data Classes
        public class appConfig
        {
            //Advantage of C# 3.0 automatic properties feature
            public string dataSource { get; set; }
            public string connectionString { get; set; }
            public string URL { get; set; }
            public string getContentsWCFUrl { get; set; }
        }

        //this class is also used by panelMenu control
        public class menuBinding
        {
            //Advantage of C# 3.0 automatic properties feature
            public int Id { get; set; }
            public string Title { get; set; }
            public List<string> Items { get; set; }
        }
        public class appContents
        {
            //Advantage of C# 3.0 automatic properties feature
            public string Title { get; set; }
            public string Abstract { get; set; }
            public string TitleUri { get; set; }
            public string ImageUri { get; set; }
            public string VidUri { get; set; }
        }

        //this class is also used by Rss2Reader control
        public class feedItem
        {
            //Advantage of C# 3.0 automatic properties feature
            public string Title { get; set; }
            public string Url { get; set; }
        }
        #endregion

        #region public initPortal method
        public void initPortal(string tpConfigURL,string tpFeedsURL)
        {
            //getting "tpConfig.xml" configuration file using WebClient
            configClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(configClient_DownloadStringCompleted);
            configClient.DownloadStringAsync(new Uri(tpConfigURL, UriKind.RelativeOrAbsolute));

            feedClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(feedClient_DownloadStringCompleted);
            //store local parameter to global variable
            tpFeedURL = tpFeedsURL;
        }

        void configClient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
         XDocument xDocConfig = XDocument.Parse(e.Result);
            var Config = (from g in xDocConfig.Descendants("TrainingPortal")

                          select new appConfig()
                          {
                              dataSource = g.Attribute("Datasource").Value,
                              connectionString = g.Element("Datasource").Element(g.Attribute("Datasource").Value).Element("connectionString").Value,
                              URL = g.Element("Datasource").Element(g.Attribute("Datasource").Value).Element("URL").Value,
                              getContentsWCFUrl = g.Element("webservice").Element("getContents").Element("serviceEndpoint").Value,
                          });

            //store config
            foreach (var item in Config)
            {
                tpConfig.dataSource = item.dataSource;
                tpConfig.connectionString = item.connectionString;
                tpConfig.URL = item.URL;
                tpConfig.getContentsWCFUrl = item.getContentsWCFUrl;
            }
            xDocConfig = null;

            //Based on DataSource, get the contents to build menu of Training Portal
            switch (tpConfig.dataSource)
            {
                case "XML":
                    menuClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(menuClient_DownloadStringCompleted);
                    menuClient.DownloadStringAsync(new Uri(tpConfig.URL, UriKind.RelativeOrAbsolute));
                    break;

                case "SQL":
                    //call to generateProxy
                    generateProxy();
                    //call to webservice
                    service.menuClientAsync(tpConfig.connectionString);
                    service.menuClientCompleted += new EventHandler<TechnologyOpinion.ServiceGetContent.menuClientCompletedEventArgs>(service_menuClientCompleted);
                    break;
            }

        }

        void feedClient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
           XDocument xDocFeed = XDocument.Parse(e.Result.ToString());
             feed = (from cat in xDocFeed.Root.Elements("feed")
                                            select new tpDataLayer.feedItem()
                                            {
                                                Title = cat.Element("Title").Value,
                                                Url = cat.Element("Url").Value,
                                            }).ToArray();

            xDocFeed = null;
            initPortalCompleted(this, menu, feed);

        }

        void menuClient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            xDoc = XDocument.Parse(e.Result.ToString());
            //parsing xml
                            menu =
                           (from cat in xDoc.Root.Elements("Category")
                            select new menuBinding()
                            {
                                Id = (int)cat.Attribute("Id"),
                                Title = (string)cat.Attribute("Title"),
                                Items = (from row in cat.Elements("Training")
                                         select (string)row.Element("Track")).Distinct().ToList()
                            }).ToArray();

            
            // menu data is ready. So it is time to read tpFeeds.xml file and parse it so we can return both parametres of initPortalComplted with
            // sufficient data to intialize the various Training Portal components 
            feedClient.DownloadStringAsync(new Uri(tpFeedURL, UriKind.RelativeOrAbsolute));
        }

        void service_menuClientCompleted(object sender, TechnologyOpinion.ServiceGetContent.menuClientCompletedEventArgs e)
        {
            menu = new menuBinding[e.Result.Count+1]; 
            foreach (var item in e.Result)
            {
                menu[item.Id] = new menuBinding();
                menu[item.Id].Id = item.Id;
                menu[item.Id].Title = item.Title;
                menu[item.Id].Items = item.Items;
            }

            // menu data is ready. So it is time to read tpFeeds.xml file and parse it so we can return both parametres of initPortalComplted with
            // sufficient data to intialize the various Training Portal components 
            feedClient.DownloadStringAsync(new Uri(tpFeedURL, UriKind.RelativeOrAbsolute));

        }
       #endregion

        #region public getContent method
        public void getContent(string selectedItem, string selectedMenuId)
        {
            switch (tpConfig.dataSource)
            {
                case "XML":
                    //parse the in memory copy of tpContents.xml i.e. xDoc
                   var rowData =
                        (from cat in xDoc.Root.Elements("Category")
                         where cat.Attribute("Id").Value == selectedMenuId.ToString()
                         select new 
                         {
                            trainings = (from training in cat.Elements("Training")
                                     where training.Element("Track").Value == selectedItem 
                                     select new appContents()
                                     {
                                         Title = training.Element("Title").Value,
                                         Abstract = training.Element("Abstract").Value,
                                         TitleUri = training.Element("TitleUri").Value,
                                         ImageUri = training.Element("ImgUri").Value,
                                         VidUri = training.Element("VidUri").Value,
                                     }
                                    
                            )
                            
                         });
                    
            foreach (var item in rowData )
    	    {
               content = item.trainings.ToArray<appContents>(); 
		 	}

                    getContentCompleted(this, content);
                    break;

                case "SQL":
                    //call to generateProxy
                    generateProxy();
                    //call to webservice
                    service.contentClientAsync(selectedItem, selectedMenuId,tpConfig.connectionString);
                    service.contentClientCompleted += new EventHandler<TechnologyOpinion.ServiceGetContent.contentClientCompletedEventArgs>(service_contentClientCompleted);
                    break;
            }
        }

        void service_contentClientCompleted(object sender, TechnologyOpinion.ServiceGetContent.contentClientCompletedEventArgs e)
        {
            content = new appContents[e.Result.Count];
            int countTo = e.Result.Count;
            int incr = 0;
            foreach (var item in e.Result)
            {

                content[incr] = new appContents();
                content[incr].Title = item.Title;
                content[incr].Abstract = item.Abstract;
                content[incr].TitleUri = item.TitleUri;
                content[incr].ImageUri = item.ImageUri;
                content[incr].VidUri = item.VidUri;
                incr++;
            }

            getContentCompleted(this, content);

        }
       #endregion

        //This method creates the "getContents" service proxy 
        private void generateProxy()
        {
            //SL 2 supports only Basic http binding 
            BasicHttpBinding serviceBinding = new BasicHttpBinding();
            //Endpoint address for service 
            EndpointAddress serviceURI = new EndpointAddress(tpConfig.getContentsWCFUrl);
            //creates service proxy based on endpoint from tpConfig.xml
            service = new TechnologyOpinion.ServiceGetContent.IgetContentClient(serviceBinding, serviceURI);
        }
    }
}