﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
//added
using TechnologyOpinion;


namespace TrainingPortal
{
    public partial class Page : UserControl
    {
        TechnologyOpinion.tpDataLayer tpLayer = new TechnologyOpinion.tpDataLayer();
        //Index for unique naming of thumbnails
        int idx = 0;

        #region DeepZoom variables
        public bool mouseIsDragging = false;
        public Point dragOffset;
        public Point pLast;
        bool mouseButtonPressed = false;
        #endregion

        public Page()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(Page_Loaded);
            new MouseWheelHelper(this).Moved += delegate(object sender, MouseWheelEventArgs e)
            {
                double zoomFactor = 1.55;
                if (e.Delta < 0)
                zoomFactor = 1 / 1.55;
                zoom(zoomFactor, pLast);
            };
        }

        #region initialize Portal

        //Here we initialize our custom controls
        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            //initializing portal
            tpLayer.initPortal("tpConfig.xml","tpFeeds.xml");
            tpLayer.initPortalCompleted += new tpDataLayer.initPortalCompletedEventHandler(tpLayer_initPortalCompleted);
            tpLayer.getContentCompleted += new TechnologyOpinion.tpDataLayer.getContentCompletedEventHandler(tpLayer_getContentCompleted);

            //setting tpVidStage mediaPlayer buttons
            tpVidStage.playImgUri = new Uri("res/play.png", UriKind.RelativeOrAbsolute);
            tpVidStage.pauseImgUri = new Uri("res/pause.png", UriKind.RelativeOrAbsolute);
            tpVidStage.rewindImgUri = new Uri("res/rewind.png", UriKind.RelativeOrAbsolute);
            tpVidStage.forwardImgUri = new Uri("res/forward.png", UriKind.RelativeOrAbsolute);
            tpVidStage.stopImgUri = new Uri("res/stop.png", UriKind.RelativeOrAbsolute);
            tpVidStage.volMinusImgUri = new Uri("res/volMinus.png", UriKind.RelativeOrAbsolute);
            tpVidStage.volPlusImgUri = new Uri("res/volPlus.png", UriKind.RelativeOrAbsolute);
           
        }

        
        void tpLayer_initPortalCompleted(object sender, tpDataLayer.menuBinding[] eMenu, tpDataLayer.feedItem[] eFeed)
        {
            //generate menu
            foreach (var item in eMenu)
            {
                if (item != null)
                {
                    tpMenu.addMenuItem(item.Id, item.Title, item.Items.ToList());
                }
            }

            //fill the "feedBox" ComboBox by setting ItemSource
            feedBox.ItemsSource = eFeed;
        }

        #endregion
        //Fullscreen toggle command
        private void fullScreenToggle(object sender, MouseButtonEventArgs e)
        {
            if (goFullscreen.Text == "Full Screen")
                goFullscreen.Text = "Normal Screen";
            else
                goFullscreen.Text = "Full Screen";

            Application.Current.Host.Content.IsFullScreen = !Application.Current.Host.Content.IsFullScreen;

        }

        //Feed ComboBox
        private void feedBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            currentStage(tpFeed);
            tpDataLayer.feedItem selectedFeed = (tpDataLayer.feedItem)e.AddedItems[0];
            tpFeed.getFeed(new Uri(selectedFeed.Url, UriKind.RelativeOrAbsolute));
        }

        //central method to set visibility of the one control at a time (tpFeed or tpMsi or tpVidstage)
        void currentStage(FrameworkElement controlToShow)
        {
            //hide all
            tpInfoPanel.Visibility = Visibility.Collapsed;
            tpFeed.Visibility = Visibility.Collapsed;
            tpMsi.Visibility = Visibility.Collapsed;
            tpVidStage.Visibility = Visibility.Collapsed;
            tpVidStage.stopMediaPlayer();
            //currently visible 
            controlToShow.Visibility = Visibility.Visible;
        }

        #region Thumbnails generation
        private void tpMenu_itemClicked(object sender, SelectionChangedEventArgs e)
        {
            //If condition to prevent itemClicked Event raised on menu button click
            if (e.AddedItems.Count != 0)
            {
                fadeIn.Stop();
                fadeIn.SetValue(Storyboard.TargetNameProperty, "thumbBar");
                fadeIn.Begin();
                //clear previous thumbnails
                thumbBar.Children.Clear();
                tpLayer.getContent(e.AddedItems[0].ToString(), tpMenu.selectedMenuId.ToString());
            }
        }

        void tpLayer_getContentCompleted(object sender, TechnologyOpinion.tpDataLayer.appContents[] e)
        {

            //Now create thumbnails
            foreach (var item in e)
            {

                    thumbnails tn = new thumbnails();
                    tn.Name = "Thumb" + idx.ToString();
                    tn.titleText = item.Title;
                    tn.abstractText = item.Abstract;
                    tn.imageUri = item.ImageUri;
                    tn.vidUri = item.VidUri;
                    tn.titleUri = item.TitleUri;
                    //Right margin for spacing between thumbnails
                    tn.Margin = new Thickness(0, 0, 8, 0);
                    //Assign three event handlers
                    tn.onLaunchImage += new MouseButtonEventHandler(tn_onLaunchImage);
                    tn.onLaunchVideo += new MouseButtonEventHandler(tn_onLaunchVideo);
                    tn.onThumbnailEnter += new MouseEventHandler(tn_onThumbnailEnter);
                    //Add to thumbBar stackpanel
                    thumbBar.Children.Add(tn);
                    //increment for unique naming
                    idx++;
                }

        }

        #endregion

        #region Thumbnails eventHandlers

        void tn_onThumbnailEnter(object sender, MouseEventArgs e)
        {
            currentStage(tpInfoPanel);
            thumbnails tnRef = (thumbnails)sender;
            Title.Text = tnRef.titleText;
            Abstract.Text = tnRef.abstractText;
        }

        void tn_onLaunchVideo(object sender, MouseButtonEventArgs e)
        {
            currentStage(tpVidStage);
            thumbnails tnRef = (thumbnails)sender;
            this.tpVidStage.setMediaPlayerSource(new Uri(tnRef.vidUri, UriKind.RelativeOrAbsolute));
        }

        void tn_onLaunchImage(object sender, MouseButtonEventArgs e)
        {
            currentStage(tpMsi);
            thumbnails tnRef = (thumbnails)sender;
            this.pLast = new Point(0, 0);
            this.tpMsi.ViewportOrigin = new Point(0, 0);
            this.tpMsi.ViewportWidth = 1.0;
            this.tpMsi.Source = new DeepZoomImageTileSource(new Uri(tnRef.imageUri, UriKind.RelativeOrAbsolute));
        }

        #endregion

        #region DeepZoom integration

        private void tpMsi_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            mouseIsDragging = false;
            mouseButtonPressed = true;
            pLast = tpMsi.ViewportOrigin;
            dragOffset = e.GetPosition(this);
        }

        private void tpMsi_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            mouseButtonPressed = false;
            pLast = e.GetPosition(this.tpMsi);
            double zoomFactor = 1.55;
            if (mouseIsDragging == false)
            {
                zoom(zoomFactor, pLast);
            }
            mouseIsDragging = false;
        }

        private void tpMsi_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseButtonPressed)
                mouseIsDragging = true;

            if (mouseIsDragging)
            {
                Point newOrigin = new Point();
                newOrigin.X = pLast.X - (((e.GetPosition(tpMsi).X - dragOffset.X) / tpMsi.ActualWidth) * tpMsi.ViewportWidth);
                newOrigin.Y = pLast.Y - (((e.GetPosition(tpMsi).Y - dragOffset.Y) / tpMsi.ActualHeight) * tpMsi.ViewportWidth);
                tpMsi.ViewportOrigin = newOrigin;
            }
        }

        public void zoom(double zoom, Point pointToZoom)
        {
            if (tpMsi.Visibility == Visibility.Visible)
            {
                Point pz = tpMsi.ElementToLogicalPoint(pointToZoom);
                tpMsi.ZoomAboutLogicalPoint(zoom, pz.X, pz.Y);
            }
        }

        #endregion

    }
}
