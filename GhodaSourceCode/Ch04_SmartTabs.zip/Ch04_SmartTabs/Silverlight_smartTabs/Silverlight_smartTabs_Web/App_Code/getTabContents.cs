﻿using System;
using System.Collections;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Net;
/// <summary>
/// This webservice retrievs xml for tab contents.
/// </summary>
[WebService(Namespace = "http://technologyopinion.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class getTabContents : System.Web.Services.WebService
{
    string sXML;
    bool isReceived;
    //Webclient to retrieve remote tabDefinition.xml file.
    WebClient wbc = new WebClient();


    public getTabContents()
    {
        isReceived = false;

    }

    [WebMethod]
    public string getTabCons()
    {
        //call to webclient
        wbc.DownloadStringAsync(new Uri("http://localhost:4353/Silverlight_smartTabs_Web/tabContents.xml"));
        wbc.DownloadStringCompleted += new DownloadStringCompletedEventHandler(wbc_DownloadStringCompleted);

        //if condition to make sure that sXML is not returned null
    waitTillFinish:
        if (isReceived == true)
            return sXML;
        else
            goto waitTillFinish;
    }
    void wbc_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
    {
        sXML = e.Result;
        isReceived = true;
    }


}

