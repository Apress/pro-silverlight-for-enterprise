﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;


namespace Silverlight_smartTabs
{
    public partial class Page : UserControl
    {
        tabDefinition tabNav = new tabDefinition();

        public Page()
        {
            InitializeComponent();
            tabNav.HorizontalAlignment = HorizontalAlignment.Left;
            tabNav.VerticalAlignment = VerticalAlignment.Top;
            masterHolder.Children.Add(tabNav);
        }


    }
}
