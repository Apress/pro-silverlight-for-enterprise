﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.IO;
using System.Net;
using System.Windows.Media.Imaging;



namespace Silverlight_smartTabs
{
    public partial class tabDefinition : UserControl
    {
        //string array to hold tab contents
        public string[,] contents = new string[100, 5];
        //in memory image cache for tab's rollover effect
        BitmapImage[] imgOn = new BitmapImage[11];
        BitmapImage[] imgOff=new BitmapImage[11];
        //image array for tab creation
       public Image [] tab = new Image [11];
        //String to hold information about tab orientation
       public  string tabOrientation;
        //int to hold tab count (number of tabs but not more than 10)
       public  int tabCount = new int();

        public tabDefinition()
        {
            InitializeComponent();
            //Here we call getTabDefinition web service and setup tab images for mouseOver and normal state.
            getTabDefinition.getTabDefinitionSoapClient getTab = new Silverlight_smartTabs.getTabDefinition.getTabDefinitionSoapClient();

            getTab.getTabDefAsync();
            getTab.getTabDefCompleted +=new EventHandler<Silverlight_smartTabs.getTabDefinition.getTabDefCompletedEventArgs>(getTab_getTabDefCompleted);
            
                  }

        void getTab_getTabDefCompleted(object sender, Silverlight_smartTabs.getTabDefinition.getTabDefCompletedEventArgs e)
        {
            //call to processTab method 
            processTab(e.Result.ToString());
        }
        
        //parsing XML and assinging its value to diff. object which will be used to makeup tabs later
        public void processTab(string sXML)
        {
            //use of LINQ TO XML to parse sXML string
            XDocument xDoc = XDocument.Parse(sXML.Remove(0, 3));

            // to get information about tab orientation and tab count(no of tabs)
            var l = from t in xDoc.Descendants("tabs")
                         select new
                         {
                             ori = t.Attribute("orientation").Value,
                             cnt=  t.Attribute("count").Value,
                         };
            foreach (var itm in l)
            {
                tabOrientation = itm.ori.ToString();
                tabCount= int.Parse(itm.cnt);
               
            }

            //storing of image uri to imgPath array for mouseOver and out image
            var v = from g in xDoc.Descendants("tab")

                    select new
                    {
                        id = g.Attribute("id").Value,
                        imgOff= g.Element("imgOff").Value,
                        imgOn = g.Element("imgOn").Value,
                    };


            foreach (var itm in v)
            {
                // image allocation
                imgOn[int.Parse(itm.id)] = new BitmapImage(new Uri(itm.imgOn));
                imgOff[int.Parse (itm.id)] = new BitmapImage(new Uri(itm.imgOff));
            }
            //Now we have sufficient data to call buildTab method
            buildTab(tabOrientation,tabCount,imgOff);
    
        }

        // based on processTab, actual implementation of each tab and its behavior  
        public void buildTab(string tabOrientation,int tabCount, BitmapImage[] imgOff)
        {
            //set orientation of tabholder stackpanel based on tabOrientation value
            if (tabOrientation.ToUpper() == "VERTICAL")
            {
                tabHolder.Orientation = Orientation.Vertical;

                //Based on orientation, changes needed in grid Layout
                ColumnDefinition c1 = new ColumnDefinition();
                ColumnDefinition c2 = new ColumnDefinition();
                LayoutRoot.ColumnDefinitions.Add(c1);
                LayoutRoot.ColumnDefinitions.Add(c2);
                //we put tabHolder stackpanel in column 0 and the contentsHolder would be in column 1.
                tabHolder.SetValue(Grid.ColumnProperty, 0);
                contentsHolder.SetValue(Grid.ColumnProperty, 1);

            }
            else
            {
                tabHolder.Orientation = Orientation.Horizontal;
                //Based on orientation, changes needed in grid Layout
                RowDefinition r1 = new RowDefinition();
                RowDefinition r2 = new RowDefinition();
                LayoutRoot.RowDefinitions.Add(r1);
                LayoutRoot.RowDefinitions.Add(r2);

                //we put tabHolder stackpanel in row 0 and the contensHolder would be in row 1.
                tabHolder.SetValue(Grid.RowProperty, 0);
                contentsHolder.SetValue(Grid.RowProperty,1);
            }
            //tab generation in tabHolder Stackpanel
                for (int count = 1; count < tabCount + 1; count++)
                {
                    //image allocation
                    tab[count] = new Image();
                    //Giving unique 1 to 10 naming to each tab object to later identify them in MouseEnter event handler
                    tab[count].Name = count.ToString();
                    //setting up some required properties 
                    tab[count].Stretch = Stretch.None;
                    tab[count].Source = imgOff[count];

                    //add to tabholder stackpanel
                    tabHolder.Children.Add(tab[count]);
                  

                }

            //assigning eventhandler for mouseEnter event, using try catch block if tabs are less than 10 
                int index = 1;
                try
                {
                    for(index=1;index<11;index++)
                    
                        if (index==11)
                        break;
                    
                    else 
                    {
                    tab[index].MouseEnter += new MouseEventHandler(tab_MouseEnter);
                    }               }
                catch (NullReferenceException e)
                {
                    //Exception handling here...
                }
            //now buildTabs is finish. So it is time to call processContents method
                processContents();
        }
        
        //methods called upon tab_mouseEnter event
        void tab_MouseEnter(object sender, MouseEventArgs e)
        {
            Image tabRef = (Image)sender;
            int tempId = int.Parse(tabRef.Name);
            resetTabs(tempId);
            buildContents(tempId );
            tab[tempId].Source = imgOn[tempId];

        }
  

        //resetTabs method for proper tab mouseOver and out effect
        public void resetTabs(int tabId)
        {
           for (int index = 1; index < tabCount + 1;index++ )
           {
            
            if (index == tabId)
            continue;
            tab[index].Source = imgOff[index];
            }

        }
 

        //call webservice to get tab contents as xml 
        public void processContents()
        {
            //Here we call getTabContents web service and will receive XML which will makeup tab contents.
            getTabContents.getTabContentsSoapClient getContent = new Silverlight_smartTabs.getTabContents.getTabContentsSoapClient();
            getContent.getTabConsAsync();
            getContent.getTabConsCompleted += new EventHandler<Silverlight_smartTabs.getTabContents.getTabConsCompletedEventArgs>(getContent_getTabConsCompleted);

        }

        //parsing XML and assinging its value to diff. object which will be used to makeup tabs contents later
        void getContent_getTabConsCompleted(object sender, Silverlight_smartTabs.getTabContents.getTabConsCompletedEventArgs e)
        {
            int i = 0;
            //use of LINQ TO XML to parse xml string
            XDocument xDoc = XDocument.Parse(e.Result.Remove(0, 3));

            //parsing of each tab contents
            var v = from g in xDoc.Descendants("content")

                    select new
                    {
                        id = g.Attribute("tabid").Value,
                        title = g.Element("title").Value,
                        hlink = g.Element("hlink").Value,
                        img = g.Element("img").Value,
                        desc = g.Element("desc").Value,
                    };

            //storing of above parsed values to contents string array
            foreach (var itm in v)
            {
                i++;
                contents[i, 0] = itm.id;
                contents[i, 1] = itm.title;
                contents[i, 2] = itm.hlink;
                contents[i, 3] = itm.img;
                contents[i, 4] = itm.desc;
            }
        }

        // based on getContent_getTabConsCompleted, actual implementation of each tab contents  
        public void buildContents(int tabId)
        {

            //clear any previous contents
            contentsHolder.Children.Clear();

            //set values based on tabId from contents string array (which we constructed in "getContent_getTabConsCompleted")
            //need to loop through whole array
            for (int i = 1; i < 101; i++)
            {
                if (contents[i, 0] == null)
                    break;
                else if (int.Parse(contents[i, 0]) == tabId)
                {
                    //create tabContent object from userControl "tabContent.xaml"
                    tabContent tabConts = new tabContent();

                        tabConts.title.Content=contents[i,1];
                        tabConts.title.NavigateUri = new Uri(contents[i, 2]);
                        //tabConts.icon.SetValue(Image.SourceProperty,new Uri (contents[i,3],UriKind.RelativeOrAbsolute ));
                       BitmapImage bmp= new BitmapImage (new Uri (contents[i,3],UriKind.RelativeOrAbsolute ));
                    tabConts.icon.Source = bmp;
                        
                    tabConts.details.Text = contents[i, 4];
                        contentsHolder.Children.Add(tabConts);
                    
                }

            }
        }

                          
    }
        
}
